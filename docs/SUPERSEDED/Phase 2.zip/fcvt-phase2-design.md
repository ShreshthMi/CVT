# FCVT — Phase 2 Design

In-flight Phase 2 architecture. Companion to `fcvt-codebase.md` (Phase 1 reference) and `fcvt-phase1-history.md` (the path that got us here). Updated as design progresses; current state reflects the early-Phase-2 design freeze around May 2026.

Decisions are captured in narrative form. Where a decision was reached in a sync meeting, the meeting itself lives in `fcvt-meeting-and-strategy.md`; this document carries the resulting design intent.

---

## Setting

Phase 2 extends FCVT from project-agnostic single-file validation into **input-dependent project-specific validation**. Where Phase 1 asks the safety engineer to enter project values via UI dropdowns and then matches them against the corresponding `.ADC` file entries, Phase 2 takes its expectations from two upstream design-baseline artifacts — the FCT2 archive (the design tool's project export) and the PDQ workbook (the configuration control tables and CQ-IR mapping) — and validates the delivered `.ADC` files against those.

The framing from the Phase 1 rebuttal applies unchanged: the FCT2 export and the PDQ are human-authored, human-reviewed upstream artifacts. The tool flags where the delivered ADC diverges from them. This remains a designer-side preflight, not an attestation and not a verifier replacement.

Phase 2 keeps every Phase 1 property: stateless backend, no database, fail-fast on load, BDD-driven. The new work extends — never replaces — what Phase 1 ships.

---

## 1. Input model

Phase 2 introduces **three input streams**:

1. **ADC files** — same upload as Phase 1, via `POST /api/upload/adcfiles`. Treated as validation targets only.
2. **FCT2 archive** — `.fct2` zipped project export. New endpoint `POST /api/upload/fct`. Only `Project.xml` is parsed; the trackplan XMLs inside the archive are out of scope.
3. **PDQ workbook** — `.xlsx` containing the CQ-IR (via `MappingProperties`) and the `ConfigControlTable` (via DP-name literal match, case/whitespace significant). New endpoint `POST /api/upload/pdq`. The Data Transmission Output subsheet is also extracted for Cluster 6.

The existing UI form (the one Phase 1 uses for direct value entry) becomes the **manual fallback** for projects without a properly formatted PDQ or FCT2. Once PDQ + FCT are both uploaded, the entire UI form freezes read-only — not just CFG_SWITCH fields, the whole form. Project code is surfaced for context.

Backend remains stateless. No database, no cross-request state beyond the per-request `DuplicateValueRegistry` from Phase 1. The Cucumber BDD suite is extended, not replaced — every Phase 1 scenario must continue to pass through the Phase 2 changes.

---

## 2. The coupled-artifacts decision (locked)

**`/api/config/validate` cannot be triggered unless BOTH PDQ and FCT are uploaded, OR NEITHER.** No partial-input validation. This is a hard architectural commitment.

The reasoning is failure-mode-driven: Cluster 1 Check A on FCT alone would pass `SLCT_TIMEOUT` consistency against an unverified reference AEB. Reference AEB correctness needs PDQ's `ConfigControlTable`. A passing rule against a wrong reference AEB **hides** real configuration errors, which is worse than no check at all. The same logic applies to every FCT-touching cluster.

The consequence is explicit: for projects without a properly formatted PDQ, Phase 2 validation is **not available** for that project. Manual review remains the path. Partial-input support would significantly increase development cost and time without increasing validation value.

This decision was reached in the May 2026 design freeze and recorded against the prior version of the design (which had treated FCT and PDQ as independent uploads — that earlier shape is superseded).

---

## 3. Endpoints — three endpoints total

### 3.1 `POST /api/upload/fct` (new)

- **In:** `.fct2` archive (multipart, ≤10 MB file / 15 MB request / 20 MB threshold; in-memory only, no spool).
- **Out:** `ComAebMap` JSON — the shape documented in §5.3.
- **Parses Project.xml only.** Trackplan XMLs out of scope.
- **Fail-fast** on the first invalid condition. Two external error codes; details in §5.4.

### 3.2 `POST /api/upload/pdq` (new)

- **In:** `.xlsx` workbook (typical size 200 KB – 2 MB).
- **Out:** Parsed PDQ JSON containing CQ-IR + ConfigControlTable + DT Output subsheet.
- **Response shape:** **[TBD]** — being designed later, with parser-complexity guardrails. Cluster-level consumers (Clusters 3, 4, 5, 6) depend on what the parser exposes; the shape lock is gated on parser scope.

### 3.3 `POST /api/config/validate` (existing, payload extended)

- The existing Phase 1 endpoint. Payload extended so `userValidationInputCriteria` also carries the FCT upload response (ComAebMap) and the PDQ upload response (parsed PDQ), in addition to the existing `parsedConfigFiles` (ADCs from `/upload/adcfiles`).
- All Phase 1 behavior preserved.

---

## 4. Validate-time backend flow

Phase 2 introduces a two-stage flow inside `/validate` once both PDQ and FCT are present.

### 4.1 Preprocessor (validate-time, in-memory)

Built fresh per `/validate` request. Scoped to method-local variables. Stateless — no caching, no shared singleton, no fields that survive the request.

**Inputs:** `ComAebMap` (from FCT upload response) + parsed PDQ (from PDQ upload response). Both are guaranteed present because of the coupled-artifacts rule.

**Outputs:**

- **Expectations JSON** — keyed `(ADC file, block, instance, entry) → expected value`. This is the external source the engine consumes as its expected-value lookup.
- **Virtual-pair scaffold** — channels grouped by `(homeCom, consumingCom)` with `requiredAebIds[]` per channel. Used by Cluster 1 Check B.

**Source-of-truth rule (locked):** ADC files are validation **targets** only. Nothing in the preprocessor reads from ADC. Expectations come from the design baseline (FCT + PDQ), never from the artifact under test.

This rule corrects an earlier design that had the preprocessor reading SLCT_TIMEOUT from ADCs. The current design derives expected SLCT_TIMEOUT from ComAebMap segment membership (see §7.1) and treats whatever the ADC contains as the actual value to be compared.

The `ComIpMap` and self-IP findings that featured in the older design have been **dropped**. COM file IP validation is out of scope for Phase 2 (§10). If it gets reintroduced later, it will be static checks only — format validity, distinctness, existence in the expected list — not file-sourced cross-referencing.

### 4.2 Engine extension

The existing rule engine consumes the expectations JSON as an additional external input source. Two rule-shape mappings:

- **Check A** → InputMatch-style. Per `(ADC file, block, instance, entry)`, engine looks up expected value in expectations JSON and compares against the actual ADC value.
- **Check B** → list-membership (closest existing analog: `MultipleBlockMultipleInputMatch`). Engine evaluates the actual `CFG_FWRD_ACD` entry set against the expected set per `(homeCom file, channel)`.

The existing 9 rule types (codebase.md §7) **stretch to cover Phase 2**. No new rule types are required structurally — what's needed is a new lookup mechanism.

**Engine extension needed:** composite-key lookup mode for `(file, block, instance, entry)`. **[TBD: mechanism still open — JSONPath in rule config vs named Java lookups. Tradeoff parked; to be resolved before BE-05 implementation starts.]**

All Phase 1 rules continue to pass; the Cucumber suite is extended, not replaced.

---

## 5. FCT upload endpoint — design depth

The FCT upload endpoint is the most fully specified piece of Phase 2 and the first BE story to land (BE-03). The Vinod sync notes captured the design as it stands; this section consolidates them with the architecture decisions made since.

### 5.1 File identification

`.fct2` extension check + ZIP magic-byte stream check. Sample only the first 8 KB → 40 KB for identification.

**Root layout expected:** 8 files + ≤2 folders (trackplan folders optional, can be 0, 1, or 2).

**[TBD: exact 8 root filenames + 2 folder names]** — needed for both proper file identification and malformed-FCT rejection during parse. Sourced from a sample FCT2 archive; not yet enumerated in the design.

### 5.2 Security and resource limits

- Multipart in-memory only, no spool: 10 MB file / 15 MB request / 20 MB threshold.
- Decompression ratio cap: 50:1.
- Total uncompressed size cap: 50 MB.
- Per-entry uncompressed cap: 20 MB.
- Nested-archive rejection via filename scan (no archives inside the FCT2).
- Password-protected archive rejection via ZIP General Purpose bit 0.

**[TBD: Spring Boot 4.0.2 multipart default override behavior]** — need to verify how SB4 defaults interact with the in-memory configuration before locking the multipart pipeline.

### 5.3 Project.xml hierarchy (parsed structure)

```
ProjectElements > Station > Cubicle > Rack > Bp
```

`Bp` children: `Psc`, `Com`, `Aeb`, `IoExb`. `Bp` has `@internId` and `CanConnections` previous/next (linked by `internId`).

| Element | Attributes / children of interest |
|---|---|
| `Com` | `@name`, `Id`, `ComType`, `ComVersion` |
| `Aeb` | `@name`, `@cpName` (DP name), `@internId`, `@slotId`, `Id`, `Information/@device` (equipmentVersion, e.g. `GS07`), `Fmas`, `IoExbBehaviour`, `IoExbControl` |
| `Fma` | `@internId`, `@fmaId`, `@aebInternId`, child `<Id>` |
| `IoExb` | `@name` (e.g. an ACO label), `RefAeb` → `Aeb` `internId`, `AxleCountingOutput/OutputFma1/2` → `Fma` `internId`s |

### 5.4 ComAebMap construction (parse-time)

CAN segment membership is built from the `Bp` chain. `Bp`s are linked via `CanConnections` previous/next by `@internId`. Each chain has:

- **1 Com** — normal case. `Com.@name` joins to ADC `[IDENTIFICATION] ID`. The chain's `Com.Id` and `Com.@name` are exposed on the ComAebMap.
- **2 Coms with `ComMode` MASTER + SLAVE** — redundancy case. The SLAVE is discarded; only MASTER survives. `redundantComPresent: true` is set on the chain.

All `Aeb`s in the chain are physical members of that CAN segment. The `Aeb`'s `Id`, `@name`, `Information/@device` (equipmentVersion), `Fmas`, and IoExb-related children are exposed per AEB.

### 5.5 FCT upload 200 response shape

```json
{
  "chains": [
    {
      "com": { "comId": "...", "comName": "..." },
      "redundantComPresent": true,
      "aebs": [
        {
          "aebId": "...",
          "aebName": "...",
          "evaluatedFmas": [
            {
              "name": "...",
              "fmaId": "...",
              "aebInternId": "..."
            }
          ],
          "acoIoExbs": [
            {
              "label": "...",
              "outputFma1Name": "...",
              "outputFma1Id": "...",
              "outputFma1AebId": "...",
              "outputFma2Name": "...",
              "outputFma2Id": "...",
              "outputFma2AebId": "..."
            }
          ],
          "dtIoExbCount": 0
        }
      ]
    }
  ]
}
```

Shape conventions:

- `chains[]` — one per CAN segment.
- `com` — single object per chain (post-redundancy collapse).
- `redundantComPresent` — always present, boolean.
- `aebs[]` — physical AEB members of the segment.
- `evaluatedFmas[]` — per AEB, FMAs whose `@aebInternId` resolves to this AEB. Surfaces `name` (from `@name`), `fmaId` (from `@fmaId`), and the parent AEB id per FMA. This entry is present in the current response shape (corrects an earlier shape that did not include it).
- `acoIoExbs[]` — IoExbs with ACO mode. Each entry's `label` is the IoExb's `@name` (free-text). `OutputFma1` and `OutputFma2` are resolved at parse time: text → `Fma@internId` → `Fma@aebInternId` → `Aeb<Id>`. The resolved FMA's `@name`, `@fmaId`, and `<Id>` are exposed under the `outputFma{1,2}Name/Id/AebId` triplet. Single-track ACOs omit `outputFma2*` fields. Note that an ACO IoExb's resolved FMA can reference an AEB different from the IoExb's host AEB — this is supported.
- `dtIoExbCount` — DT-mode IoExb count only. The inner DT data comes from PDQ, not from the FCT.
- All IDs serialised as JSON strings.

### 5.6 Error contract (locked)

External rejection: **single code, no detail**. Two external codes only:

| Code | Meaning |
|---|---|
| `FCT_TAMPERED` | Cross-reference or invariant fail during ComAebMap build. XML parse failure folds into this category. Catches the case where someone has manually edited the FCT after export. |
| `FCT_INCOMPLETE_BASELINE` | Pre-export incomplete-baseline FCT: dangling `CanConnections`, chain with no COM, multi-COM chain without redundancy pairing, unsupported IoExb mode, duplicate or missing entity `Id` where `Id` is `0` or `4096`. |

Parse-layer rejections (HTTP 400 for malformed multipart, HTTP 413 for size exceedance) remain unchanged — these are pre-business-logic and don't get folded into the two codes.

Internally, a `FctInvalidException` carries a lazy enum with `INCOMPLETE_*` variants for each specific cause + a `TAMPERED` catch-all. The external response only surfaces the two codes; the internal variants drive logging and debugging.

### 5.7 Counting-head-output IoExb rejection

Only ACO and DT modes are in scope for Phase 2. If a counting-head-output mode IoExb is present in the FCT, the upload is rejected (likely under `FCT_INCOMPLETE_BASELINE` since it's a baseline-shape constraint, **[TBD: exact code mapping]**).

---

## 6. Cluster overview

Phase 2 validation organises around **6 clusters**, each owning a set of `(block, key)` validations. The clusters map to source artifacts as follows:

| Cluster | Concern | Source artifact |
|---|---|---|
| 1 — CAN Segment | Cross-COM/AEB ID resolution, SLCT_TIMEOUT, CFG_FWRD_ACD forwarding | FCT ComAebMap + PDQ CCT |
| 2 — IOEXB ACO | IoExb position within board rack; number of ACO IoExbs per AEB | FCT ComAebMap (acoIoExbs) |
| 3 — Track Section | Sub-checks for CHC counting-head assignment, sensors-per-track, supervisory track config, ACO/DT IO assignment | PDQ CCT |
| 4 — CHC / External CHC | Combined cluster; same block, different validation approaches per sub-cluster | PDQ CCT |
| 5 — Supervisor | FMA Supervisor validation | PDQ CCT |
| 6 — Data Transmission | `CFG_DATA_OUT`, `CFG_DATA_SAFETY_LEVELS` | PDQ Data Transmission Output subsheet |

### 6.1 The Cluster 1 / Cluster 2 ownership rule (locked)

Both Cluster 1 and Cluster 2 touch `CFG_SECTION_OUT`. The ownership split is structural:

- **Cluster 1 owns `ID` and `SLCT_TIMEOUT` validation across every in-scope block.** This includes `CFG_ZP_FMA1`, `CFG_ZP_FMA2`, `CFG_SECTION_OUT`, `CFG_CONTROL`, `CFG_SUPERVIS_FMA1/2`, `CFG_DATA_OUT`. The cluster that nominally owns the host block (e.g. Cluster 2 owning `CFG_SECTION_OUT` for its other validations) does **not** also do ID/SLCT_TIMEOUT. Cluster 1 does.
- **Cluster 2 also validates `ID` and `SECTION` on `CFG_SECTION_OUT`**, but with **different semantics**: position-within-rack and IoExb-count, not cross-reference resolution.

Both clusters run on the same block; their failure modes do not overlap. This is the structural commitment, not an emergent property.

### 6.2 Cluster blocks and keys

Detailed block and key specifics for each cluster:

**Cluster 1 — CAN Segment**
- Blocks: `CFG_ZP_FMA1`, `CFG_ZP_FMA2`, `CFG_SECTION_OUT`, `CFG_CONTROL`, `CFG_SUPERVIS_FMA1`, `CFG_SUPERVIS_FMA2`, `CFG_DATA_OUT`
- Keys: `ID`, `SLCT_TIMEOUT` (validated wherever these keys appear, across all in-scope blocks); plus `CFG_FWRD_ACD` entries (Check B forwarding validation)
- Source: FCT ComAebMap + PDQ CCT
- Detail in §7.

**Cluster 2 — IOEXB ACO**
- Block: `CFG_SECTION_OUT`
- Keys: `ID`, `SECTION` (validates IoExb position within board rack + number of ACO IoExbs attached to each AEB); plus block count per file
- Source: FCT ComAebMap (`acoIoExbs`)
- Detail in §8.

**Cluster 3 — Track Section**
- Blocks: **[TBD from Confluence requirements doc]**
- Keys: **[TBD from Confluence requirements doc]**
- Source: PDQ CCT
- Known structure: 4 sub-checks — (1) CHC counting head assignment per sensor/ADC, (2) correct sensors per track section, (3) supervisory track config, (4) ACO/DT IO assignment. Sub-checks 1 and 4 can be ADC-only. Sub-checks 2 and 3 require station layout as external input. **[TBD: station layout input strategy — file upload vs inline UI vs ADC-only scope. The same decision covers parallel sub-clusters elsewhere.]**

**Cluster 4 — CHC / External CHC**
- Combined cluster; same block, different validation approaches per sub-cluster.
- Blocks: `CFG_CONTROL` (external CHC, ≤2 per ADC); also touches `CFG_ZP` for adjacency.
- Keys: **[TBD from Confluence requirements doc]**
- Source: PDQ CCT
- Known mapping: CHC count is derived from `BEHAV_IN3` in ConfigControlTable Track table — `BEHAV_IN3 = 7` → 1 `CFG_CONTROL` block; `BEHAV_IN3 = 6` → 2 `CFG_CONTROL` blocks. Adjacency information is derived from the same Track table.

**Cluster 5 — Supervisor**
- Blocks: **[TBD from Confluence requirements doc — 3B FMA Supervisor block details pending re-confirmation against the Confluence requirements doc]**
- Keys: **[TBD]**
- Source: PDQ CCT

**Cluster 6 — Data Transmission**
- Blocks: `CFG_DATA_OUT`, `CFG_DATA_SAFETY_LEVELS`
- Keys: **[TBD from Confluence requirements doc]**
- Source: PDQ Data Transmission Output subsheet
- Note: this supersedes an earlier-noted scope that included `CFG_DATA_IO SAFETY_LEVEL_IN/OUT` — that reference was incorrect and has been discarded.

---

## 7. Cluster 1 detail (CAN Segment)

Cluster 1 is the most fully specified cluster in the current design. The two checks and their assumptions are below.

### 7.1 Check A — per-AEB identity and SLCT_TIMEOUT

For each AEB `.ADC` file:

1. **AEB identity lookup.** Read `[IDENTIFICATION] ID` from the ADC. Look it up in ComAebMap. If miss → emit an **ORPHANED** finding (the ADC corresponds to no AEB in the FCT2-defined CAN segments).
2. **Per in-scope block, ref AEB validation.** For each in-scope block with a referenced AEB id, look up that AEB.Id in ComAebMap. If miss → emit a **FILE NOT FOUND** finding (the referenced AEB doesn't exist in the design baseline).
3. **Physical / virtual classification.** Compare the ComAebMap segment membership of the referencing AEB vs the referenced AEB. Same segment → **physical**; different segment → **virtual** (record into the virtual-pair scaffold for Check B).
   - The classification comes from **ComAebMap segment membership**, not from the ADC's `SLCT_TIMEOUT` value. The ADC value is the *actual* to be validated, not the source of truth.
4. **Expected SLCT_TIMEOUT.** Derived from the physical/virtual classification:
   - `0` = same segment (physical)
   - `1` = different segment (virtual)
5. **Engine compares actual SLCT_TIMEOUT vs expected** as an InputMatch-style rule.
   - `2..7` in actual → emit **INVALID SCOPE** finding (out of Phase 2's binary scope).
   - Any other value → emit **INVALID VALUE** finding.

### 7.2 Check B — virtual forwarding (CFG_FWRD_ACD)

Built on the virtual-pair scaffold from Check A.

1. **Build scaffold.** Group virtual references from ComAebMap + PDQ (CCT + DT input) by `(homeCom, consumingCom)` into **channels**, each with a `requiredAebIds[]` list.
2. **Compute expected forwarding set per channel.** For each channel, the expected set of `CFG_FWRD_ACD` entries is computed per `(homeCom file, channel)`.
3. **Engine evaluates** as a list-membership rule against the actual `CFG_FWRD_ACD` entries in the homeCom file. Missing expected entries → rule fail.

The earlier `DOWNSTREAM_IP_UNRESOLVED` finding has been **dropped** — it depended on ComIpMap, which is out of Phase 2's scope (§10).

### 7.3 Cluster 1 assumptions

Ten assumptions are documented for Cluster 1. They scope what Phase 2 commits to handling and what it doesn't:

1. All COMs in a single FCT2 share the same subnet. IP-level checks are out of scope.
2. One COM per CAN segment, with redundancy supported via `IP_SWITCH = 1`.
3. FCT2 is trusted as the source of truth. If FCT2 is wrong, FCVT's output is wrong by construction. This is acceptable because FCT2 is itself a human-reviewed artifact (the rebuttal frame applies).
4. Inter-COM references are only AEB IDs. (Originally an assumption about 3G being a separate cluster; 3G has since been subsumed into Cluster 1 because no non-AEB ID references exist between COM files. Cross-file ID resolution needed for 3G is identical to the FCT2-derived segment-membership lookup in Cluster 1. The derivation lives inside each Check A; no separate precomputed map.)
5. `SLCT_TIMEOUT` semantics: values 0–7 exist in the protocol, but Phase 2 only handles 0 and 1 (physical/virtual binary). Values 2–7 emit INVALID SCOPE findings.
6. ADC identity is resolved via `[IDENTIFICATION] ID` → FCT2 `Aeb.Id`.
7. Required forwarding destinations are derived bottom-up from the AEB-reference graph (referenced AEBs propagate their required-destination set up to their referencing AEBs).
8. Forwarding tuples are keyed by `(source AEB, destination COM)`.
9. Socket numbering: `socket = header − 32`. Check B uses NW1 only.
10. ADC export is assumed correct (the FCT export step itself is trusted; what's being validated is whether the configuration the designer authored matches what the baseline says it should be).

These assumptions are also surfaced to Salai/Max in the work-package breakdown for AE agreement.

---

## 8. Cluster 2 detail (IOEXB ACO)

Cluster 2 validates the ACO IoExb configuration against `CFG_SECTION_OUT`. The primary inputs come from FCT ComAebMap's `acoIoExbs` field.

What gets validated:

- **IoExb position within the board rack.** Each ACO IoExb has a slot/position in the rack; this must match what the ADC declares.
- **Number of ACO IoExbs attached to each AEB.** Count from ComAebMap vs count from ADC `CFG_SECTION_OUT` block occurrences.
- **Block count per file.** `CFG_SECTION_OUT` ≤ 16 per file is the documented bound.

Note again the Cluster 1/2 ownership rule (§6.1): Cluster 2 owns `ID` and `SECTION` on `CFG_SECTION_OUT` with different semantics than Cluster 1's ID/SLCT_TIMEOUT. Both run; no failure-mode overlap.

---

## 9. Clusters 3–6 (current state)

Clusters 3 through 6 have a known shape but most block/key specifics are pending against the Confluence requirements document. Inline TBDs are marked here; summary is in §11.

**Cluster 3 — Track Section.** 4 sub-checks (CHC counting head assignment, sensors-per-track, supervisory track config, ACO/DT IO assignment). Sub-checks 1 and 4 are ADC-only; sub-checks 2 and 3 require station layout as an external input — input strategy is open. **[TBD: blocks, keys, station-layout input strategy]**

**Cluster 4 — CHC / External CHC.** Combined cluster spanning the standard CHC and the External CHC sub-cluster. CHC count derivation is locked: `BEHAV_IN3 = 7 → 1 CFG_CONTROL block`; `BEHAV_IN3 = 6 → 2 CFG_CONTROL blocks`. Adjacency from ConfigControlTable Track table. External CHC scope: `CFG_CONTROL` ≤ 2 per ADC. **[TBD: full blocks, keys list, sub-cluster split]**

**Cluster 5 — Supervisor.** Mapped to FMA Supervisor work. **[TBD: blocks, keys — 3B FMA Supervisor block details pending re-confirmation against Confluence requirements doc]**

**Cluster 6 — Data Transmission.** Blocks locked: `CFG_DATA_OUT`, `CFG_DATA_SAFETY_LEVELS`. The earlier-noted `CFG_DATA_IO SAFETY_LEVEL_IN/OUT` reference was incorrect and is discarded. **[TBD: full keys list, rule semantics]**

---

## 10. Out of scope (Phase 2)

Items explicitly excluded from Phase 2; flag if asked.

- **COM file IP validation.** Deferred. If reintroduced later, **static checks only** (valid format, distinct, exists in expected list). Not file-sourced cross-referencing. The earlier `ComIpMap` and self-IP findings have been dropped.
- **3G as a separate cluster.** Subsumed into Cluster 1 (CAN Segment). No non-AEB ID references exist between COM files; cross-file ID resolution is identical to the segment-membership lookup in Cluster 1's Check A. Worth flagging in the work-package breakdown to Salai/Max — removes one new-engine-capability dependency from Phase 2 scope.
- **Trackplan XMLs inside the FCT archive.** Only `Project.xml` is parsed. Trackplan XMLs are not opened.
- **Counting-head-output mode IoExbs.** Only ACO and DT modes are in scope. FCT is rejected if a counting-head-output mode IoExb is present.

---

## 11. Open items (TBDs, summary)

Centralised list of every TBD called out inline:

| # | Item | Blocks |
|---|---|---|
| 1 | PDQ upload response shape | Cluster 3, 4, 5, 6 implementation; gated on parser scope |
| 2 | Engine composite-key lookup mechanism — JSONPath in rule config vs named Java lookups | BE-05 onwards implementation |
| 3 | Exact 8 root filenames + 2 folder names in FCT archive | FCT identification + malformed-FCT rejection during parse |
| 4 | Spring Boot 4.0.2 multipart default override behavior — verify | FCT upload pipeline lock |
| 5 | Cluster 3 blocks and keys (Track Section), station-layout input strategy | BE-06 (Track Section cluster) |
| 6 | Cluster 4 full blocks/keys (CHC / External CHC), sub-cluster split | BE-07 / BE-08 |
| 7 | Cluster 5 blocks and keys (Supervisor), 3B FMA Supervisor re-confirmation | BE-09 |
| 8 | Cluster 6 full keys list and rule semantics | BE-11 |
| 9 | Counting-head-output IoExb rejection — exact error code mapping | FCT upload error contract finalisation |

---

## 12. Epic and child-story structure (VTF 2.0.0)

The Phase 2 epic is **VTF 2.0.0**. Formal target: end of July 2026. (See `fcvt-meeting-and-strategy.md` for Max's informal pressure toward end of June and the negotiation context.)

Child stories grouped by frontend / backend cluster work:

**Frontend (FE-01 through FE-03):**
- FE-01 — CFG_SWITCH UI (carries over the Phase 1 pending CFG_SWITCH work, codebase.md §14).
- FE-02 — FCT2 and PDQ upload wiring.
- FE-03 — Post-PDQ form freeze (the read-only state once both uploads are in).

**Backend infrastructure (BE-01 through BE-04):**
- BE-01 / BE-02 — PDQ parser. BE-01 covers CQ-IR; BE-02 covers ConfigControlTable.
- BE-03 — FCT2 parser. The endpoint design in §5.
- BE-04 — PDF report generation. **Stretch goal** for Phase 2; not on the critical path.

**Backend cluster work (BE-05 through BE-11):** one story per cluster.

- BE-05 — Cluster 1 (CAN Segment)
- BE-06 — Cluster 2 (IOEXB ACO) — *or BE-06 → Cluster 3 (Track Section); mapping by code rather than cluster number is the working convention*
- BE-07, BE-08, BE-09, BE-10, BE-11 — one per remaining cluster

The specific BE-cluster mapping is subject to finalisation in the work-package breakdown to AE (see meeting-and-strategy.md for the May 7 sync where this was actioned).

---

*End of Phase 2 design — current to May 2026 design freeze. Updates required as cluster requirements close out and TBDs resolve.*
